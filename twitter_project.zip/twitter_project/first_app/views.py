from django.shortcuts import render
from first_app.models import Tweet, User
# Create your views here.

def index(request):
	return render(request, 'index.html')

def latest_tweets(request):
	last_tweets = {
	 'tweet' : Tweet.objects.all().order_by('-date')[:20],
	 }
	return render(request, 'last_tweets.html', context=last_tweets)

def gets_all_tweets_of_user(user_id):
    all_tweets = {
    'tweet' : Tweet.objects.filter(user= user_id)
    }
    return all_tweets

def user_profile(request, user_id):
	return render(request, 'user_profile.html', context=gets_all_tweets_of_user(user_id))
