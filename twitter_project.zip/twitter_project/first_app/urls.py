from django.urls import path
from . import views

urlpatterns = [
	path('', views.index, name='index'),
	path('last_tweets/', views.latest_tweets, name='last_tweets' ),
	path('user_profile/<int:user_id>', views.user_profile, name='user_profile'),
]