from django.contrib import admin
from first_app.models import User, Tweet

# Register your models here.
admin.site.register(User)
admin.site.register(Tweet)
